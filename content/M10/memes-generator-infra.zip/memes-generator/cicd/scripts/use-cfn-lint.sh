#!/bin/bash
cfn-lint -i W -- ${PROJECT}/**/templates/**/*.yaml