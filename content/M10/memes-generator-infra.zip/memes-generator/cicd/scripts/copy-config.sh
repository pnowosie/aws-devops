#!/bin/bash
set -ex;
mkdir -p build/$PROJECT/application/config
cp -r $PROJECT/application/config build/$PROJECT/application